<?php

/*depricated*/
class Rcl_EditFields extends Rcl_Custom_Fields_Manager{

    function __construct($post_type, $options = false){
        parent::__construct($post_type, $options);
    }

}
