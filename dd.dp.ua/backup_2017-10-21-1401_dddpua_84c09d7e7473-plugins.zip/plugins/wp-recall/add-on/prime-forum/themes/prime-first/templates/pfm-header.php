<div class="prime-forum-header">
    
    <?php do_action('pfm_header'); ?>

    <?php pfm_the_breadcrumbs(); ?>

    <div class="prime-forum-search">
        <?php pfm_the_search_form(); ?>
    </div>

</div>

