<?php
wp_clear_scheduled_hook('hourly_notify_new_message');