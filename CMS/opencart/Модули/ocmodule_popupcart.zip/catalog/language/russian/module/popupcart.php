<?php
// Heading 
$_['heading_title'] = 'Всплывающая корзина';

// Text
?>