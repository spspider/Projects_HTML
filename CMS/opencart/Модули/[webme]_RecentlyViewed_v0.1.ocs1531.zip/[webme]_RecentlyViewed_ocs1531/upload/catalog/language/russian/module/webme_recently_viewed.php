<?php
// Heading
$_['heading_title_personal'] = 'Вы смотрели';
$_['heading_title_overall'] = 'Популярные';

// Text
$_['text_stars']     = '%s из 5 звезд!';
?>