<?php
// Heading
$_['heading_title_personal'] = 'Recently Viewed';
$_['heading_title_overall'] = 'Most popular';

// Text
$_['text_stars']     = '%s out of 5 Stars!';
?>