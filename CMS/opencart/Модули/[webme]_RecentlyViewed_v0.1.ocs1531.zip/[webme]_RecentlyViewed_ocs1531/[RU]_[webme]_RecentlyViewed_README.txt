/*===============================================*\
|*
|* @charset: utf-8
|*
|* mod.name: [WebMe] Recently Viewed
|*
|* version: 0.1.ocs1531
|* release date: 2013.03.05
|*
|* версии ocStore, на которых тестировалось дополнение: 1.5.3.1, 1.5.4.1 (считается, что поддерживаются версии - 151-1541)
|* версии OpenCart, на которых тестировалось дополнение: 1.5.3.1, 1.5.4.1 (считается, что поддерживаются версии - 151-1541)
|*
|* author: afwollis <afwollis@gmail.com>
|* idea: Norman aka i2Paq <http://forum.opencart.com/memberlist.php?mode=viewprofile&u=7322>
|*
\*===============================================*/


Этот БЕСПЛАТНЫЙ модуль предоставили вам afwollis (http://www.webme.com.ua/) и i2Paq

#################################################
# Что он делает
##############

Модуль будет показывать Х наиболее просматриваемых (Популярных) товаров вашего магазина, когда клиент впервые зайдет на ваш сайт.
"Х" легко регулируется в админке магазина.
Также вы можете отключить данную опцию!

Как только клиент просмотрит какой-нибудь товар "Популярные товары" заменятся списком "Недавно просмотренных" этим клиентом.
Это очень удобно, так как ваш клиент может осмотреться в вашем магазине, а затем быстро вернуться к заинтересовавшему его продукту.
Количество "просмотренных товаров", выводимых клиенту также легко настраивается в админке.



#################################################
# Новые файлы
##############

[=== ADMIN ===]
admin/controller/module/webme_recently_viewed.php
admin/language/english/module/webme_recently_viewed.php
admin/language/russian/module/webme_recently_viewed.php
admin/view/template/module/webme_recently_viewed.tpl

[=== CATALOG ===]
catalog/controller/module/webme_recently_viewed.php
catalog/language/english/module/webme_recently_viewed.php
catalog/language/russian/module/webme_recently_viewed.php
catalog/model/module/webme_recently_viewed.php
catalog/view/theme/default/template/module/webme_recently_viewed.tpl

[=== IMAGE ===]
catalog/view/theme/default/image/recently_viewed.png


##################################################################################################
#
# Установка
#

###############################################################
ШАГ --- 1 ---
##############

Загрузите файлы из папки "upload" в корневую директорию вашего магазина.


###############################################################
ШАГ --- 2 ---
##############

Пройдите в [=== админка -> дополнения -> модули ===] найдите модуль "[WebMe] Недавно просмотренные" и нажмите "Установить".


###############################################################
ШАГ --- 3 ---
##############

[=== catalog/controller/product/product.php ===]

Найдите строку:
= = =
	public function index() {
= = =

Замените её на:
= = =
	public function index() {
		/* [WebMe] Recently Viewed */
		$this->initPersonalRecentlyViewed();
		/* [WebMe] Recently Viewed */
= = =

#####

Ниже в этом же файле, ПЕРЕД
= = =
}
?>
= = =

Добавьте следующий блок:
= = =
	/* [WebMe] Recently viewed */
	private function initPersonalRecentlyViewed() {
		
		$personalRecentlyViewed = array();
		$personalRecentlyViewedLimit = $this->config->get('webme_recently_viewed_personal_limit');
		$overallRecentlyViewedStatus = $this->config->get('webme_recently_viewed_overall_status');
		$overallRecentlyViewedLimit = $this->config->get('webme_recently_viewed_overall_limit');
		
		$prv_limit = $personalRecentlyViewedLimit;
		$prv = array();
		
		if (isset($this->request->cookie['personalRecentlyViewed'])) {
			$this->session->data['personalRecentlyViewed'] = explode("_", $this->request->cookie['personalRecentlyViewed']);
		}
		
		if ($prv_limit > 0) {
			if (isset($this->request->get['product_id'])) {
				$prv[] = $this->request->get['product_id'];
				
				if (isset($this->session->data['personalRecentlyViewed'])) {
					foreach($this->session->data['personalRecentlyViewed'] as $i => $new_prv) {
						if (count($prv) == $prv_limit) {
							break;
						}
						
						if (!in_array($new_prv, $prv)) {
							$prv[] = $new_prv;
						}
					}
				}
			} else {
				if (isset($this->session->data['personalRecentlyViewed'])) {
					foreach($this->session->data['personalRecentlyViewed'] as $i => $new_prv) {
						if (count($prv) == $prv_limit) {
							break;
						}
						
						if (!in_array($new_prv, $prv)) {
							$prv[] = $new_prv;
						}
					}
				}
			}
			
			$this->session->data['personalRecentlyViewed'] = $prv;
			
			$cookie_prv = implode("_", $prv);
			
			setcookie('personalRecentlyViewed', $cookie_prv, time() + 60 * 60 * 24 * 30, '/', $this->request->server['HTTP_HOST']);
		}
		
		//return $prv;
	}
= = =


##################################################################################################
#
# Изменение настроек
#

1. Пройдите в [=== админка -> дополнения -> модули ===] найдите модуль "[WebMe] Недавно просмотренные" и нажмите "Редактировать":
	
	а) "Показывать Х последних просмотренных покупателем товаров" -> укажите некоторое число, чтобы активировать сбор информации о Недавно просмотренных клиентом товарах.
	
	б) "Показывать наиболее просматриваемые товары магазина если Покупатель еще не просмотрел ни один товар?":
		установите в ДА если вы хотите показывать "популярные товары" КОГДА НЕТ ИНФОРМАЦИИ О ПЕРСОНАЛЬНЫХ (клиентских) НедавноПросмотренных товарах.
		установите в НЕТ если вы НЕ хотите показывать "популярные товары".
	
	в) "Показывать Х наиболее просматриваемых товаров:" -> если предыдущий параметр установлен в ДА, это количество "популярных товаров" будет показано клиенту.


Если вы укажите в "Показывать Х последних просмотренных покупателем товаров" 0 (ноль), тогда "Недавно просмотренные" товары не будут показаны.
Если параметр "Показывать наиболее просматриваемые товары магазина если Покупатель еще не просмотрел ни один товар?" установлен в "ДА" и "Показывать Х наиболее просматриваемых товаров:" больше, чем 0 (ноль), тогда "Популярные товары" будут показаны.

Во всех других случаях Модуль показан НЕ БУДЕТ.


##################################################################################################
##################################################################################################
##################################################################################################

Все - модуль готов "к употреблению" !!

