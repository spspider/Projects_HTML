/*===============================================*\
|*
|* @charset: utf-8
|*
|* mod.name: [WebMe] Recently Viewed
|*
|* version: 0.1.ocs1531
|* release date: 2013.03.05
|*
|* supported ocStore versions: 1.5.3.1, 1.5.4.1 (prob - 151-1541)
|* supported OpenCart versions: 1.5.3.1, 1.5.4.1 (prob - 151-1541)
|*
|* author: afwollis <afwollis@gmail.com>
|* idea: Norman aka i2Paq <http://forum.opencart.com/memberlist.php?mode=viewprofile&u=7322>
|*
\*===============================================*/


This FREE module is brought to you by afwollis (http://www.webme.com.ua/) and i2Paq

#################################################
# What it does
##############

It will show the x amount of most looked at products on your website when a customer first visits your site.
This x amount is something you can set in your Store's Admin.
This can also be switched off!

As soon as a customer views a product the most looked at products are replaced by the last x amount of products your customer looks at.
This is very conviniant as your customer can look arround and then quickly returns to the product of his choice.
This x amount of product the customer has looked at you can also set in your Store's Admin.



#################################################
# New Files
##############

[=== ADMIN ===]
admin/controller/module/webme_recently_viewed.php
admin/language/english/module/webme_recently_viewed.php
admin/language/russian/module/webme_recently_viewed.php
admin/view/template/module/webme_recently_viewed.tpl

[=== CATALOG ===]
catalog/controller/module/webme_recently_viewed.php
catalog/language/english/module/webme_recently_viewed.php
catalog/language/russian/module/webme_recently_viewed.php
catalog/model/module/webme_recently_viewed.php
catalog/view/theme/default/template/module/webme_recently_viewed.tpl

[=== IMAGE ===]
catalog/view/theme/default/image/recently_viewed.png


##################################################################################################
#
# Installation
#

1. Upload files from an "upload" folder to your store's root directory.
2. Go to [=== admin -> extensions -> modules ===] find "[WebMe] Recently Viewed" module and click "Install".

3. [=== catalog/controller/product/product.php ===]

Find next string:
= = =
	public function index() {
= = =

Replace it with:
= = =
	public function index() {
		/* [WebMe] Recently Viewed */
		$this->initPersonalRecentlyViewed();
		/* [WebMe] Recently Viewed */
= = =

#####

Scroll down to the end of file.
Before this lines
= = =
}
?>
= = =

Add next code:
= = =
	/* [WebMe] Recently viewed */
	private function initPersonalRecentlyViewed() {
		
		$personalRecentlyViewed = array();
		$personalRecentlyViewedLimit = $this->config->get('webme_recently_viewed_personal_limit');
		$overallRecentlyViewedStatus = $this->config->get('webme_recently_viewed_overall_status');
		$overallRecentlyViewedLimit = $this->config->get('webme_recently_viewed_overall_limit');
		
		$prv_limit = $personalRecentlyViewedLimit;
		$prv = array();
		
		if (isset($this->request->cookie['personalRecentlyViewed'])) {
			$this->session->data['personalRecentlyViewed'] = explode("_", $this->request->cookie['personalRecentlyViewed']);
		}
		
		if ($prv_limit > 0) {
			if (isset($this->request->get['product_id'])) {
				$prv[] = $this->request->get['product_id'];
				
				if (isset($this->session->data['personalRecentlyViewed'])) {
					foreach($this->session->data['personalRecentlyViewed'] as $i => $new_prv) {
						if (count($prv) == $prv_limit) {
							break;
						}
						
						if (!in_array($new_prv, $prv)) {
							$prv[] = $new_prv;
						}
					}
				}
			} else {
				if (isset($this->session->data['personalRecentlyViewed'])) {
					foreach($this->session->data['personalRecentlyViewed'] as $i => $new_prv) {
						if (count($prv) == $prv_limit) {
							break;
						}
						
						if (!in_array($new_prv, $prv)) {
							$prv[] = $new_prv;
						}
					}
				}
			}
			
			$this->session->data['personalRecentlyViewed'] = $prv;
			
			$cookie_prv = implode("_", $prv);
			
			setcookie('personalRecentlyViewed', $cookie_prv, time() + 60 * 60 * 24 * 30, '/', $this->request->server['HTTP_HOST']);
		}
		
		//return $prv;
	}
= = =


##################################################################################################
#
# Edit Settings
#

1. Go to [=== admin -> extensions -> modules ===] find "[WebMe] Recently Viewed" module and click "Edit":
	
	a) "Number of the last X items viewed by customer to show" -> put some number to activate gathering "Personal" RecentlyViewed info.
	
	b) "Show the last X overall popular viewed products?":
		set to YES if you want to show overall most viewed products IF NO PERSONAL (viewed by customer) INFO AVAILABLE.
		set to NO if you don't want to show overall most viewed products IF NO PERSONAL (viewed by customer) INFO AVAILABLE.
	
	c) "Number of overall popular viewed products to show" -> if previous setting YES this number of most viewed items will be shown to customer.


IF you will set "Number of the last X items viewed by customer to show" to 0 (zero) then RecentlyViewed items will NOT be shown.
IF "Show the last X overall popular viewed products?" option turned into "YES" and "Number of overall popular viewed products to show" more than 0 (zero) then OverallMostViewed items will be shown.

In other cases there will NO any "viewed" module-block shown in frontend.


##################################################################################################
##################################################################################################
##################################################################################################

Thats all folks!!

