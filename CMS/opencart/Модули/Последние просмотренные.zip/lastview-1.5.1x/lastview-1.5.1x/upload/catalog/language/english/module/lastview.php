<?php
// Heading 
$_['heading_title'] = 'Last viewed';
?>