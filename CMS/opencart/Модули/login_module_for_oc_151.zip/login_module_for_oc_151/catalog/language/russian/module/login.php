<?php
// Heading 
$_['heading_title']				= 'Авторизация';

// Entry
$_['entry_email_address']		= 'E-Mail адрес:';
$_['entry_password']			= 'Пароль:';

// Buttons
$_['button_logout']				= 'Выйти';
$_['button_create']				= 'Зарегистрировать';
?>