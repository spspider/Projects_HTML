<?php
// Heading 
$_['heading_title']				= 'Login';

// Entry
$_['entry_email_address']		= 'E-Mail Address:';
$_['entry_password']			= 'Password:';

// Buttons
$_['button_logout']				= 'Logout';
$_['button_create']			= 'Create';
?>