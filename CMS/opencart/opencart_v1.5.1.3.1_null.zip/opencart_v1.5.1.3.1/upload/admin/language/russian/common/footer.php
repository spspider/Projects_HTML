<?php
// Text
$_['text_footer'] = '<a href="http://maxzon.ru">www.maxzon.ru - Поддержка OpenCart</a> &copy; 2009-' . date('Y') . ' All Rights Reserved.<br />Версия %s';
?>