<?php
// Heading
$_['heading_title']     = 'Отчет о клиентах онлайн';

// Text 
$_['text_guest']        = 'Гость';
 
// Column
$_['column_ip']         = 'IP';
$_['column_customer']   = 'Клиент';
$_['column_url']        = 'Последняя просмотреная страница';
$_['column_referer']    = 'Откуда пришел';
$_['column_date_added'] = 'Последний переход';
$_['column_action']     = 'Действие';
?>